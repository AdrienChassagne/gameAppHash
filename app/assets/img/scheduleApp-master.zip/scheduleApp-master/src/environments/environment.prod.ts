export const environment = {
  production: false,
  firebase: {
    apiKey: 'AIzaSyB0ylDNU0rb-Ixp7FOJq0_aD9QKqpUiILU',
    authDomain: 'agenda-eaa09.firebaseapp.com',
    databaseURL: 'https://agenda-eaa09.firebaseio.com',
    projectId: 'agenda-eaa09',
    storageBucket: 'agenda-eaa09.appspot.com',
    messagingSenderId: '797168931254'
  }
};
