# scheduleApp

This project was generated with [Angular CLI](https://github.com/angular/angular-cli)

ToDos: log view style, cleaner less, better routing, help tooltips, year view, finish responsive/media queries

Demo: https://adrienchassagne.github.io/scheduleApp/
